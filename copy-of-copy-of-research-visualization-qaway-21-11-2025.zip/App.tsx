
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect } from 'react';
import { Menu, X, Instagram, Linkedin, Mail } from 'lucide-react';
import { HomeSection, CoursesSection, BlogSection, ServicesSection, ContactSection } from './components/Sections';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<'home' | 'cursos' | 'blog' | 'servicios' | 'contacto'>('home');
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNav = (view: typeof currentView) => {
    setCurrentView(view);
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const NavLink = ({ view, label }: { view: typeof currentView, label: string }) => (
    <button 
      onClick={() => handleNav(view)} 
      className={`text-sm font-bold uppercase tracking-wider transition-colors ${currentView === view ? 'text-qaway-magenta' : 'text-qaway-dark hover:text-qaway-yellow'}`}
    >
      {label}
    </button>
  );

  return (
    <div className="min-h-screen flex flex-col font-sans selection:bg-qaway-yellow selection:text-qaway-dark">
      
      {/* Header */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/95 backdrop-blur-md shadow-sm py-4' : 'bg-white py-6'}`}>
        <div className="container mx-auto px-6 flex justify-between items-center">
          {/* Logo */}
          <div className="cursor-pointer z-50" onClick={() => handleNav('home')}>
             {/* Text Logo representation based on description */}
             <div className="flex items-center gap-1">
                <span className="text-3xl font-black text-qaway-yellow leading-none tracking-tighter">Q</span>
                <span className="text-2xl font-bold text-qaway-dark leading-none">away</span>
             </div>
             <span className="text-[0.6rem] font-bold text-gray-400 uppercase tracking-[0.2em] block ml-1">Marketing & Asesoría</span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            <NavLink view="home" label="Home" />
            <NavLink view="cursos" label="Cursos" />
            <NavLink view="servicios" label="Servicios" />
            <NavLink view="blog" label="Blog" />
            <button 
              onClick={() => handleNav('contacto')} 
              className="px-6 py-2 bg-qaway-dark text-white rounded-full text-sm font-bold hover:bg-qaway-magenta transition-colors shadow-md"
            >
              Contacto
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden p-2 text-qaway-dark z-50" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>

        {/* Mobile Menu Overlay */}
        {menuOpen && (
          <div className="fixed inset-0 bg-white flex flex-col items-center justify-center gap-8 animate-fade-in md:hidden">
             <button onClick={() => handleNav('home')} className="text-2xl font-bold text-qaway-dark">Home</button>
             <button onClick={() => handleNav('cursos')} className="text-2xl font-bold text-qaway-dark">Cursos</button>
             <button onClick={() => handleNav('servicios')} className="text-2xl font-bold text-qaway-dark">Servicios</button>
             <button onClick={() => handleNav('blog')} className="text-2xl font-bold text-qaway-dark">Blog</button>
             <button onClick={() => handleNav('contacto')} className="text-2xl font-bold text-qaway-magenta">Contacto</button>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-grow pt-20">
        {currentView === 'home' && <HomeSection setView={handleNav} />}
        {currentView === 'cursos' && <CoursesSection />}
        {currentView === 'blog' && <BlogSection />}
        {currentView === 'servicios' && <ServicesSection />}
        {currentView === 'contacto' && <ContactSection />}
      </main>

      {/* Footer */}
      <footer className="bg-qaway-dark text-white pt-16 pb-8">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-1 mb-4">
                  <span className="text-3xl font-black text-qaway-yellow leading-none tracking-tighter">Q</span>
                  <span className="text-2xl font-bold text-white leading-none">away</span>
              </div>
              <p className="text-gray-400 leading-relaxed max-w-sm mb-6">
                Conectamos investigación, estrategia y creatividad para construir marcas sólidas. Crecimiento medible a través del conocimiento.
              </p>
              <div className="flex gap-4">
                <a href="#" className="text-gray-400 hover:text-qaway-yellow transition-colors"><Instagram size={24}/></a>
                <a href="#" className="text-gray-400 hover:text-qaway-yellow transition-colors"><Linkedin size={24}/></a>
                <a href="#" className="text-gray-400 hover:text-qaway-yellow transition-colors"><Mail size={24}/></a>
              </div>
            </div>
            
            <div>
              <h4 className="font-bold text-lg mb-4 text-qaway-yellow">Explora</h4>
              <ul className="space-y-2 text-gray-400">
                <li><button onClick={() => handleNav('home')} className="hover:text-white transition-colors">Inicio</button></li>
                <li><button onClick={() => handleNav('servicios')} className="hover:text-white transition-colors">Servicios</button></li>
                <li><button onClick={() => handleNav('cursos')} className="hover:text-white transition-colors">Cursos</button></li>
                <li><button onClick={() => handleNav('blog')} className="hover:text-white transition-colors">Blog</button></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-lg mb-4 text-qaway-yellow">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Política de Privacidad</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Términos y Condiciones</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Libro de Reclamaciones</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center text-gray-500 text-sm">
            <p>&copy; {new Date().getFullYear()} Qaway Marketing & Asesoría. Todos los derechos reservados.</p>
            <p>Lima, Perú</p>
          </div>
        </div>
      </footer>

    </div>
  );
};

export default App;
