
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';
import { ArrowRight, BarChart, BookOpen, Target, Users, Lightbulb, CheckCircle, Instagram, Linkedin, Mail, MapPin, Phone, MessageSquare } from 'lucide-react';

// --- COMPONENTS ---

const SectionTitle = ({ title, subtitle }: { title: string, subtitle?: string }) => (
  <div className="mb-12 text-center">
    <h2 className="text-3xl md:text-4xl font-bold text-qaway-dark mb-4">{title}</h2>
    {subtitle && <p className="text-lg text-gray-600 max-w-2xl mx-auto">{subtitle}</p>}
    <div className="w-24 h-1 bg-qaway-yellow mx-auto mt-6 rounded-full"></div>
  </div>
);

const Card = ({ icon: Icon, title, description, highlight = false }: { icon: any, title: string, description: string, highlight?: boolean }) => (
  <div className={`p-8 rounded-2xl transition-all duration-300 hover:-translate-y-2 ${highlight ? 'bg-qaway-dark text-white shadow-xl' : 'bg-white border border-qaway-border shadow-sm hover:shadow-md'}`}>
    <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-6 ${highlight ? 'bg-qaway-yellow text-qaway-dark' : 'bg-qaway-gray text-qaway-yellowLight'}`}>
      <Icon size={24} strokeWidth={2.5} />
    </div>
    <h3 className={`text-xl font-bold mb-3 ${highlight ? 'text-white' : 'text-qaway-dark'}`}>{title}</h3>
    <p className={`leading-relaxed ${highlight ? 'text-gray-300' : 'text-gray-600'}`}>{description}</p>
  </div>
);

// --- SECTIONS ---

export const HomeSection = ({ setView }: { setView: (view: string) => void }) => (
  <div className="animate-fade-in">
    {/* Hero */}
    <section className="relative py-20 md:py-32 overflow-hidden bg-qaway-gray">
      <div className="absolute top-0 right-0 w-1/3 h-full bg-qaway-yellow/10 skew-x-[-20deg] translate-x-20 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-qaway-magenta/5 rounded-full blur-3xl pointer-events-none"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl">
          <div className="inline-block px-4 py-2 bg-white border border-qaway-border rounded-full text-sm font-bold text-qaway-dark tracking-wider mb-6 shadow-sm">
            MARKETING & ASESORÍA
          </div>
          <h1 className="text-5xl md:text-7xl font-black text-qaway-dark leading-tight mb-6">
            Estrategia y Conocimiento para <span className="bg-gradient-to-r from-qaway-yellow to-qaway-yellowLight bg-clip-text text-transparent">Marcas que Crecen</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-10 max-w-2xl font-light">
            Investigación, estrategia, analítica y creatividad conectadas para construir ecosistemas de marketing integrales.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button onClick={() => setView('servicios')} className="px-8 py-4 bg-qaway-yellow hover:bg-qaway-yellowLight text-qaway-dark font-bold rounded-full transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2 group">
              Explorar Servicios <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform"/>
            </button>
            <button onClick={() => setView('cursos')} className="px-8 py-4 bg-white border-2 border-qaway-dark text-qaway-dark font-bold rounded-full hover:bg-qaway-dark hover:text-white transition-all flex items-center justify-center">
              Ver Cursos
            </button>
          </div>
        </div>
      </div>
    </section>

    {/* Intro/Philosophy */}
    <section className="py-24 bg-white">
      <div className="container mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
        <div>
          <h2 className="text-3xl font-bold mb-6 text-qaway-dark">Más que una agencia, somos tu socio estratégico.</h2>
          <p className="text-lg text-gray-600 leading-relaxed mb-6">
            En <span className="font-bold text-qaway-dark">Qaway</span>, creemos que el marketing efectivo nace de la intersección entre los datos y la creatividad. No nos limitamos a ejecutar campañas; construimos sistemas.
          </p>
          <p className="text-lg text-gray-600 leading-relaxed mb-8">
             Nuestra misión es empoderar a emprendedores y profesionales con estrategias claras y conocimiento aplicable, eliminando las conjeturas del crecimiento empresarial.
          </p>
          <div className="grid grid-cols-2 gap-6">
             <div className="flex items-start gap-3">
                <CheckCircle className="text-qaway-magenta mt-1 shrink-0" size={20}/>
                <span className="font-medium text-qaway-dark">Crecimiento Medible</span>
             </div>
             <div className="flex items-start gap-3">
                <CheckCircle className="text-qaway-magenta mt-1 shrink-0" size={20}/>
                <span className="font-medium text-qaway-dark">Enfoque Integral</span>
             </div>
             <div className="flex items-start gap-3">
                <CheckCircle className="text-qaway-magenta mt-1 shrink-0" size={20}/>
                <span className="font-medium text-qaway-dark">Conocimiento Compartido</span>
             </div>
             <div className="flex items-start gap-3">
                <CheckCircle className="text-qaway-magenta mt-1 shrink-0" size={20}/>
                <span className="font-medium text-qaway-dark">Estrategia + Acción</span>
             </div>
          </div>
        </div>
        <div className="relative h-full min-h-[400px] bg-qaway-gray rounded-2xl overflow-hidden flex items-center justify-center">
           {/* Abstract Visual */}
           <div className="absolute inset-0 opacity-20">
              <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,#ffaa00_0%,transparent_70%)]"></div>
           </div>
           <div className="relative z-10 text-center p-8">
              <div className="text-8xl font-black text-qaway-dark/10 mb-4">Q</div>
              <p className="text-2xl font-bold text-qaway-dark">Investigación + Creatividad</p>
           </div>
        </div>
      </div>
    </section>

    {/* Services Highlights */}
    <section className="py-24 bg-qaway-gray">
      <div className="container mx-auto px-6">
        <SectionTitle title="Nuestras Soluciones" subtitle="Diseñamos servicios adaptados a cada etapa de tu negocio, desde la consultoría estratégica hasta la formación especializada." />
        
        <div className="grid md:grid-cols-3 gap-8">
          <Card 
            icon={Target} 
            title="Consultoría Estratégica" 
            description="Diagnóstico profundo y planes de acción claros para marcas que necesitan reorientar su rumbo y escalar." 
          />
          <Card 
            icon={Users} 
            title="Gestión de Marcas" 
            description="Construcción de identidad, voz y presencia digital coherente que resuene con tu audiencia ideal." 
            highlight={true}
          />
          <Card 
            icon={BookOpen} 
            title="Formación & Cursos" 
            description="Capacitación práctica para equipos y emprendedores que desean dominar sus propias herramientas de marketing." 
          />
        </div>

        <div className="mt-16 text-center">
          <button onClick={() => setView('servicios')} className="text-qaway-dark font-bold border-b-2 border-qaway-yellow hover:bg-qaway-yellow hover:border-transparent px-4 py-2 transition-colors">
            Ver Todos los Servicios
          </button>
        </div>
      </div>
    </section>
  </div>
);

export const ServicesSection = () => (
  <div className="pt-24 pb-24 animate-slide-up">
    <div className="bg-qaway-dark text-white py-20 mb-16">
      <div className="container mx-auto px-6">
        <h1 className="text-4xl md:text-6xl font-bold mb-6">Servicios</h1>
        <p className="text-xl text-gray-300 max-w-2xl">Soluciones integrales para cada desafío de marketing.</p>
      </div>
    </div>

    <div className="container mx-auto px-6 space-y-24">
      {/* Service 1 */}
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="order-2 md:order-1">
          <div className="w-16 h-16 bg-qaway-yellow/20 text-qaway-yellow rounded-2xl flex items-center justify-center mb-6">
            <Target size={32} />
          </div>
          <h3 className="text-3xl font-bold mb-4 text-qaway-dark">Consultoría de Marketing</h3>
          <p className="text-gray-600 leading-relaxed mb-6">
            Analizamos tu situación actual, competencia y mercado para desarrollar una hoja de ruta personalizada. Ideal para empresas que se sienten estancadas o buscan nuevos horizontes.
          </p>
          <ul className="space-y-3 mb-8">
            <li className="flex items-center gap-2 text-gray-700"><div className="w-2 h-2 bg-qaway-magenta rounded-full"></div> Auditoría de marca y digital</li>
            <li className="flex items-center gap-2 text-gray-700"><div className="w-2 h-2 bg-qaway-magenta rounded-full"></div> Definición de Buyer Persona</li>
            <li className="flex items-center gap-2 text-gray-700"><div className="w-2 h-2 bg-qaway-magenta rounded-full"></div> Plan de Marketing Anual</li>
          </ul>
        </div>
        <div className="order-1 md:order-2 bg-gray-100 h-[300px] rounded-xl flex items-center justify-center border border-gray-200">
            <div className="text-gray-400 font-bold text-lg">Imagen Consultoría</div>
        </div>
      </div>

      {/* Service 2 */}
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="bg-gray-100 h-[300px] rounded-xl flex items-center justify-center border border-gray-200">
           <div className="text-gray-400 font-bold text-lg">Imagen Gestión Digital</div>
        </div>
        <div>
          <div className="w-16 h-16 bg-qaway-magenta/10 text-qaway-magenta rounded-2xl flex items-center justify-center mb-6">
            <BarChart size={32} />
          </div>
          <h3 className="text-3xl font-bold mb-4 text-qaway-dark">Marketing Digital & Social Ads</h3>
          <p className="text-gray-600 leading-relaxed mb-6">
            Maximizamos tu inversión publicitaria con campañas segmentadas y optimizadas. No buscamos solo likes, buscamos conversiones y clientes reales.
          </p>
          <ul className="space-y-3 mb-8">
            <li className="flex items-center gap-2 text-gray-700"><div className="w-2 h-2 bg-qaway-yellow rounded-full"></div> Gestión de campañas Meta Ads</li>
            <li className="flex items-center gap-2 text-gray-700"><div className="w-2 h-2 bg-qaway-yellow rounded-full"></div> Google Ads & SEO Local</li>
            <li className="flex items-center gap-2 text-gray-700"><div className="w-2 h-2 bg-qaway-yellow rounded-full"></div> Analítica y Reportes de ROI</li>
          </ul>
        </div>
      </div>

      {/* Service 3 */}
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="order-2 md:order-1">
          <div className="w-16 h-16 bg-gray-900 text-white rounded-2xl flex items-center justify-center mb-6">
            <MessageSquare size={32} />
          </div>
          <h3 className="text-3xl font-bold mb-4 text-qaway-dark">Creación de Contenido & Branding</h3>
          <p className="text-gray-600 leading-relaxed mb-6">
            Desarrollamos narrativas visuales y textuales que conectan. Desde la identidad visual hasta el calendario de contenidos mensual.
          </p>
          <ul className="space-y-3 mb-8">
            <li className="flex items-center gap-2 text-gray-700"><div className="w-2 h-2 bg-qaway-magenta rounded-full"></div> Diseño de Identidad Visual</li>
            <li className="flex items-center gap-2 text-gray-700"><div className="w-2 h-2 bg-qaway-magenta rounded-full"></div> Estrategia de Contenidos</li>
            <li className="flex items-center gap-2 text-gray-700"><div className="w-2 h-2 bg-qaway-magenta rounded-full"></div> Copywriting persuasivo</li>
          </ul>
        </div>
        <div className="order-1 md:order-2 bg-gray-100 h-[300px] rounded-xl flex items-center justify-center border border-gray-200">
           <div className="text-gray-400 font-bold text-lg">Imagen Contenido</div>
        </div>
      </div>
    </div>
  </div>
);

export const CoursesSection = () => (
  <div className="pt-24 pb-24 animate-slide-up">
    <div className="bg-qaway-yellow/10 py-20 mb-16">
      <div className="container mx-auto px-6 text-center">
        <span className="text-qaway-magenta font-bold tracking-widest text-sm uppercase mb-2 block">Qaway Academy</span>
        <h1 className="text-4xl md:text-6xl font-bold mb-6 text-qaway-dark">Cursos Especializados</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">Aprende las metodologías que aplicamos con nuestros clientes. Sin rellenos, 100% accionable.</p>
      </div>
    </div>

    <div className="container mx-auto px-6">
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {/* Course Card 1 */}
        <div className="flex flex-col bg-white rounded-xl overflow-hidden border border-qaway-border shadow-sm hover:shadow-lg transition-all group">
          <div className="h-48 bg-qaway-slate flex items-center justify-center group-hover:bg-qaway-dark transition-colors">
            <Lightbulb className="text-qaway-yellow w-16 h-16" />
          </div>
          <div className="p-8 flex-1 flex flex-col">
            <div className="text-xs font-bold text-qaway-magenta mb-2 uppercase tracking-wide">Estrategia</div>
            <h3 className="text-2xl font-bold text-qaway-dark mb-3">Marketing Estratégico 360</h3>
            <p className="text-gray-600 mb-6 flex-1">Aprende a crear un plan de marketing completo desde la investigación hasta la medición de resultados.</p>
            <div className="pt-6 border-t border-gray-100 flex justify-between items-center">
               <span className="font-bold text-lg text-qaway-dark">US$ 120</span>
               <button className="px-4 py-2 bg-qaway-dark text-white rounded-lg text-sm font-bold hover:bg-qaway-yellow hover:text-qaway-dark transition-colors">Ver Temario</button>
            </div>
          </div>
        </div>

        {/* Course Card 2 */}
        <div className="flex flex-col bg-white rounded-xl overflow-hidden border border-qaway-border shadow-sm hover:shadow-lg transition-all group">
          <div className="h-48 bg-gray-200 flex items-center justify-center group-hover:bg-gray-300 transition-colors">
            <BarChart className="text-gray-500 w-16 h-16" />
          </div>
          <div className="p-8 flex-1 flex flex-col">
            <div className="text-xs font-bold text-qaway-magenta mb-2 uppercase tracking-wide">Analítica</div>
            <h3 className="text-2xl font-bold text-qaway-dark mb-3">Analítica Digital Práctica</h3>
            <p className="text-gray-600 mb-6 flex-1">Deja de temer a los números. Domina Google Analytics 4 y las métricas de redes sociales para tomar decisiones.</p>
            <div className="pt-6 border-t border-gray-100 flex justify-between items-center">
               <span className="font-bold text-lg text-qaway-dark">US$ 90</span>
               <button className="px-4 py-2 bg-qaway-dark text-white rounded-lg text-sm font-bold hover:bg-qaway-yellow hover:text-qaway-dark transition-colors">Ver Temario</button>
            </div>
          </div>
        </div>

        {/* Course Card 3 */}
        <div className="flex flex-col bg-white rounded-xl overflow-hidden border border-qaway-border shadow-sm hover:shadow-lg transition-all group">
          <div className="h-48 bg-qaway-yellow flex items-center justify-center group-hover:bg-qaway-yellowLight transition-colors">
            <Users className="text-qaway-dark w-16 h-16" />
          </div>
          <div className="p-8 flex-1 flex flex-col">
            <div className="text-xs font-bold text-qaway-dark mb-2 uppercase tracking-wide">Branding</div>
            <h3 className="text-2xl font-bold text-qaway-dark mb-3">Gestión de Marca Personal</h3>
            <p className="text-gray-600 mb-6 flex-1">Potencia tu carrera profesional construyendo una marca personal sólida, auténtica y rentable.</p>
            <div className="pt-6 border-t border-gray-100 flex justify-between items-center">
               <span className="font-bold text-lg text-qaway-dark">US$ 75</span>
               <button className="px-4 py-2 bg-qaway-dark text-white rounded-lg text-sm font-bold hover:bg-qaway-yellow hover:text-qaway-dark transition-colors">Ver Temario</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export const BlogSection = () => (
  <div className="pt-24 pb-24 animate-slide-up">
    <div className="container mx-auto px-6 mb-16">
      <h1 className="text-4xl md:text-6xl font-bold mb-6 text-qaway-dark">Blog & Recursos</h1>
      <p className="text-xl text-gray-600 max-w-2xl">Compartimos lo que aprendemos. Análisis, tendencias y guías prácticas.</p>
    </div>

    <div className="container mx-auto px-6">
       <div className="grid md:grid-cols-2 gap-12">
          {/* Featured Article */}
          <article className="md:col-span-2 grid md:grid-cols-2 gap-8 items-center bg-white rounded-2xl border border-qaway-border overflow-hidden shadow-sm hover:shadow-md transition-shadow">
             <div className="h-64 md:h-full bg-gray-200 min-h-[300px]"></div>
             <div className="p-8 md:pr-12">
                <span className="text-qaway-magenta font-bold text-sm mb-3 block">ESTRATEGIA</span>
                <h2 className="text-3xl font-bold text-qaway-dark mb-4 hover:text-qaway-yellow transition-colors cursor-pointer">¿Por qué tu marca necesita un ecosistema, no solo un funnel?</h2>
                <p className="text-gray-600 mb-6 line-clamp-3">El modelo tradicional de embudo de ventas está perdiendo efectividad. Descubre cómo construir un ecosistema de marca que retenga y fidelice a largo plazo.</p>
                <button className="text-qaway-dark font-bold border-b-2 border-qaway-yellow hover:bg-qaway-yellow px-2 py-1 transition-all">Leer Artículo Completo</button>
             </div>
          </article>

          {/* Article 2 */}
          <article className="bg-white rounded-xl border border-qaway-border overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col">
             <div className="h-48 bg-gray-100"></div>
             <div className="p-8 flex-1 flex flex-col">
                <span className="text-qaway-yellowLight font-bold text-sm mb-3 block">ANALÍTICA</span>
                <h3 className="text-xl font-bold text-qaway-dark mb-3">Métricas que realmente importan en 2024</h3>
                <p className="text-gray-600 mb-6 flex-1">Deja de mirar métricas de vanidad y enfócate en los KPIs que mueven la aguja de tu negocio.</p>
                <button className="text-qaway-dark font-bold self-start hover:text-qaway-magenta transition-colors">Leer más →</button>
             </div>
          </article>

          {/* Article 3 */}
          <article className="bg-white rounded-xl border border-qaway-border overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col">
             <div className="h-48 bg-gray-100"></div>
             <div className="p-8 flex-1 flex flex-col">
                <span className="text-qaway-magenta font-bold text-sm mb-3 block">CREATIVIDAD</span>
                <h3 className="text-xl font-bold text-qaway-dark mb-3">El poder del Storytelling en B2B</h3>
                <p className="text-gray-600 mb-6 flex-1">Cómo humanizar una marca corporativa sin perder profesionalismo ni autoridad.</p>
                <button className="text-qaway-dark font-bold self-start hover:text-qaway-magenta transition-colors">Leer más →</button>
             </div>
          </article>
       </div>
    </div>
  </div>
);

export const ContactSection = () => (
  <div className="pt-24 pb-24 bg-qaway-gray animate-slide-up">
    <div className="container mx-auto px-6 max-w-5xl">
       <div className="bg-white rounded-2xl shadow-xl overflow-hidden grid md:grid-cols-2">
          <div className="p-12 bg-qaway-dark text-white">
             <h2 className="text-3xl font-bold mb-6">Hablemos de tu proyecto</h2>
             <p className="text-gray-300 mb-12">¿Listo para escalar tu marca? Cuéntanos tus retos y encontremos la mejor estrategia para ti.</p>
             
             <div className="space-y-6">
                <div className="flex items-center gap-4">
                   <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center">
                      <Mail size={20} className="text-qaway-yellow"/>
                   </div>
                   <div>
                      <div className="text-xs text-gray-400 uppercase font-bold">Email</div>
                      <div className="text-lg font-medium">contacto@qaway.com</div>
                   </div>
                </div>
                <div className="flex items-center gap-4">
                   <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center">
                      <Phone size={20} className="text-qaway-yellow"/>
                   </div>
                   <div>
                      <div className="text-xs text-gray-400 uppercase font-bold">Teléfono</div>
                      <div className="text-lg font-medium">+51 999 000 000</div>
                   </div>
                </div>
                <div className="flex items-center gap-4">
                   <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center">
                      <MapPin size={20} className="text-qaway-yellow"/>
                   </div>
                   <div>
                      <div className="text-xs text-gray-400 uppercase font-bold">Ubicación</div>
                      <div className="text-lg font-medium">Lima, Perú / Remoto Global</div>
                   </div>
                </div>
             </div>

             <div className="mt-12 flex gap-4">
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-qaway-yellow hover:text-qaway-dark transition-colors"><Instagram size={20}/></a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-qaway-yellow hover:text-qaway-dark transition-colors"><Linkedin size={20}/></a>
             </div>
          </div>

          <div className="p-12">
             <form className="space-y-6">
                <div>
                   <label className="block text-sm font-bold text-qaway-dark mb-2">Nombre Completo</label>
                   <input type="text" className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-qaway-yellow focus:ring-1 focus:ring-qaway-yellow outline-none transition-all" placeholder="Juan Pérez" />
                </div>
                <div>
                   <label className="block text-sm font-bold text-qaway-dark mb-2">Correo Electrónico</label>
                   <input type="email" className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-qaway-yellow focus:ring-1 focus:ring-qaway-yellow outline-none transition-all" placeholder="juan@empresa.com" />
                </div>
                <div>
                   <label className="block text-sm font-bold text-qaway-dark mb-2">¿En qué podemos ayudarte?</label>
                   <select className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-qaway-yellow focus:ring-1 focus:ring-qaway-yellow outline-none transition-all">
                      <option>Consultoría Estratégica</option>
                      <option>Gestión de Marca</option>
                      <option>Cursos / Capacitación</option>
                      <option>Otro</option>
                   </select>
                </div>
                <div>
                   <label className="block text-sm font-bold text-qaway-dark mb-2">Mensaje</label>
                   <textarea className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-qaway-yellow focus:ring-1 focus:ring-qaway-yellow outline-none transition-all h-32" placeholder="Cuéntanos más sobre tu proyecto..."></textarea>
                </div>
                <button className="w-full py-4 bg-qaway-dark text-white font-bold rounded-lg hover:bg-qaway-magenta transition-colors shadow-lg">
                   Enviar Mensaje
                </button>
             </form>
          </div>
       </div>
    </div>
  </div>
);
